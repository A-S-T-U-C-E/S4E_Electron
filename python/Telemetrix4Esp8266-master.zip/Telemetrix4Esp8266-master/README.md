# Telemetrix4Esp8266
The Telemetrix Project WiFi Server For ESP-8266 Arduino-Core Devices. For instructions on use, 
see the [Telemetrix User's Guide.](https://mryslab.github.io/telemetrix/)
