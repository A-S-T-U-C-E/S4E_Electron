#ifndef _TELEMETRIX4ESP8266_H_
#define _TELEMETRIX4ESP8266_H_

class Telemetrix4Esp8266 {

public:
};

#endif //_TELEMETRIX4ESP8266_H_
