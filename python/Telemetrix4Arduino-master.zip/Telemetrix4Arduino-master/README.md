# Telemetrix4Arduino
The Telemetrix Project Server For Arduino-Core. For instructions on use, 
see the [Telemetrix User's Guide.](https://mryslab.github.io/telemetrix/)
